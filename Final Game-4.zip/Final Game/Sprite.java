import java.awt.*;
import javax.swing.*;

public abstract class Sprite {
	protected Point absolutePosition;
	protected Point relativePosition;
	protected ImageIcon image;
	
	//temp variables
	
	//constructor
	public Sprite() {
		absolutePosition = new Point();
		relativePosition = new Point();
		image = null;
	}
	
	//methods
	public void setLocation(Point p){
		if (p == null){
			absolutePosition = null;
			relativePosition = null;
		}else{
			setLocation(p.x, p.y);
		}
	}
	
	public void draw(Graphics g){
		if (absolutePosition != null){
			image.paintIcon(null, g, absolutePosition.x, absolutePosition.y);
		}
	}
	
	public void setLocation(int x, int y){
		relativePosition = new Point(x,y);
		absolutePosition = new Point((x-1)*Game.eachw,(y-1)*Game.eachh);
	}
	
	public Point getPos() {
		return relativePosition;
	}
	
	public boolean equal(Object other){
		return isTouching((Sprite)other);
	}
	
	private boolean isTouching(Sprite other) {		
		if(this.getPos().equals(other.getPos())){
			return true;
		}
		return false;
	}
	
	public boolean isNear(Sprite other) {
		Point up = new Point(this.getPos().x,this.getPos().y-1);
		Point down = new Point(this.getPos().x,this.getPos().y+1);
		Point left = new Point(this.getPos().x-1,this.getPos().y);
		Point right = new Point(this.getPos().x+1,this.getPos().y);
		if(up.equals(other.getPos())){
			return true;
		}
		if(down.equals(other.getPos())){
			return true;
		}
		if(left.equals(other.getPos())){
			return true;
		}
		if(right.equals(other.getPos())){
			return true;
		}
		return false;
	}
	

}



import javax.swing.ImageIcon;

public class Tree extends Sprite {
	
	public Tree(int x, int y){
		super();
		image = new ImageIcon("tree.png");
		setLocation(x,y);
	}
	
}

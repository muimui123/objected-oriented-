import javax.swing.ImageIcon;

public class Robber extends Sprite {
	
	public Robber(int x, int y){
		super();
		image = new ImageIcon("bad.png");
		setLocation(x,y);
	}
	
}

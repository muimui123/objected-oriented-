import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;

import java.io.FileNotFoundException;
import java.net.URL;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;



public class Game extends JPanel implements KeyListener {
	static int w;
	static int h;
	public final static int eachw = 67;
	public final static int eachh = 86;
	Ammon a;
	ArrayList <Robber> badguys; 	
	ArrayList <Sheep> flock; 
	ArrayList <Tree> forest; 
	ArrayList <Water> water;
	ArrayList <String> map;
	private int checkSheep;
	private int checkRobber;
	private Scanner map1;
	private int col;
	private int row;
	private AudioClip background;
	
	public Game() {
		forest = new ArrayList<>(); 
		water = new ArrayList<>();
		badguys = new ArrayList<>();
		flock = new ArrayList<>();
		addKeyListener(this);
		reset();
	}
	public void shoot(int k) {
	if (k == KeyEvent.VK_W) {
		Point p = a.getPos();
		linh:
		for (int y = p.y-1; y>=0; y--) {
			for(int i=0; i < badguys.size(); i++){
				if(badguys.get(i) == null){
					continue;
				}
				if(badguys.get(i).getPos().x != p.x){
					continue;
				}
				if (badguys.get(i).getPos().y == y) {
					badguys.set(i, null);
					checkRobber--;
					repaint();
					break linh;
				}
			}
			for(int i=0; i < flock.size(); i++) {
				if(flock.get(i) == null){
					continue;
				}
				if(flock.get(i).getPos().x != p.x){
					continue;
				}
				if (flock.get(i).getPos().y == y){
					reset();
					break linh;
				}
			}
			for(int i=0; i < forest.size(); i++) {
				if(forest.get(i).getPos().x != p.x){
					continue;
				}
				if (forest.get(i).getPos().y == y){
					break linh;
				}
			}
		}
	}
	
	if (k == KeyEvent.VK_S) {
		Point p = a.getPos();
		System.out.println(p.y+1 + " " + row);
		linh:
		for (int y = p.y+1; y <= row; y++) {
			for(int i=0; i < badguys.size(); i++){
				if(badguys.get(i) == null){
					System.out.println("pass null");
					continue;
				}
				if(badguys.get(i).getPos().x != p.x){
					System.out.println("pass x");
					continue;
				}
				if (badguys.get(i).getPos().y == y) {
					badguys.set(i, null);
					checkRobber--;
					repaint();
					break linh;
				}
			}
			for(int i=0; i < flock.size(); i++) {
				if(flock.get(i) == null){
					continue;
				}
				if(flock.get(i).getPos().x != p.x){
					continue;
				}
				if (flock.get(i).getPos().y == y){
					reset();
					break linh;
				}
			}
				for(int i=0; i < forest.size(); i++) {
					if(forest.get(i).getPos().x != p.x){
						continue;
					}
					if (forest.get(i).getPos().y == y){
						break linh;
				}
			}
		}
	}
	
	if (k == KeyEvent.VK_A) {
		Point p = a.getPos();
		linh:
		for (int x = p.x-1; x>=0; x--) {
			for(int i=0; i < badguys.size(); i++){
				if(badguys.get(i) == null){
					continue;
				}
				if(badguys.get(i).getPos().y != p.y){
					continue;
				}
				if (badguys.get(i).getPos().x == x) {
					badguys.set(i, null);
					checkRobber--;
					repaint();
					break linh;
				}
			}
			for(int i=0; i < flock.size(); i++) {
				if(flock.get(i) == null){
					continue;
				}
				if(flock.get(i).getPos().y != p.y){
					continue;
				}
				if (flock.get(i).getPos().x == x){
					reset();
					break linh;
				}
			}
			for(int i=0; i < forest.size(); i++) {
				if(forest.get(i).getPos().y != p.y){
					continue;
				}
				if (forest.get(i).getPos().x == x){
					break linh;
				}
			}
		}
	}
	
	if (k == KeyEvent.VK_D) {
		Point p = a.getPos();
		linh:
		for (int x = p.x+1; x<=col; x++) {
			for(int i=0; i < badguys.size(); i++){
				if(badguys.get(i) == null){
					continue;
				}
				if(badguys.get(i).getPos().y != p.y){
					continue;
				}
				if (badguys.get(i).getPos().x == x) {
					badguys.set(i, null);
					checkRobber--;
					repaint();
					break linh;
				}
			}
			for(int i=0; i < flock.size(); i++) {
				if(flock.get(i) == null){
					continue;
				}
				if(flock.get(i).getPos().y != p.y){
					continue;
				}
				if (flock.get(i).getPos().x == x){
					System.out.println("game over");
					reset();
					break linh;
				}
			}
			for(int i=0; i < forest.size(); i++) {
				if(forest.get(i).getPos().y != p.y){
					continue;
				}
				if (forest.get(i).getPos().x == x){
					break linh;
				}
			}	
		}		
	}
	}
	public void readMap(String filename) {
		Scanner map1;
		try {
			map1 = new Scanner(new File(filename));
			ArrayList<String> map = new ArrayList<String>();
			while (map1.hasNextLine()) {
				String tuti = map1.nextLine();
				map.add(tuti);
			}
			map1.close();
			row = map.size();
			col = map.get(0).length();
			System.out.println(col + " " + row);
			w = col*eachw;
			h = row*eachh;
			for(int i=0; i<map.size(); i++){
				char[] tmp = map.get(i).toCharArray();
				for(int j=0;j<tmp.length;j++){
					if(tmp[j] == 'S'){
						flock.add(new Sheep(j,i));
					}
					else if(tmp[j] == 'A'){
						if(a == null){
							a = new Ammon (j,i);
						}
						else {
							a.setLocation(j,i);
						}
					}
					else if(tmp[j] == 'W'){
						water.add(new Water(j,i));
					}
					else if(tmp[j] == 'T'){
						forest.add(new Tree(j,i));
					}
					else if(tmp[j] == 'R'){
						badguys.add(new Robber(j,i));
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void paintComponent(Graphics g) {
		requestFocusInWindow();
		
		g.setColor(new Color(204, 255, 204));
		g.fillRect(0, 0, w, h);
		
		g.setColor(Color.BLACK);
		g.drawRect(0,0,w,h);
		
		
		//draw Ammon
		a.draw(g);
		
		//draw trees
		for(Tree t: forest){
			t.draw(g);
		}
		
		//draw robbers
		for(Robber r: badguys) {
			if(r == null){
				continue;
			}
			r.draw(g);
		}
		
		//draw water
		for(Water w: water) {
			w.draw(g);
		}
		
		//draw sheep
		for(Sheep s: flock) {
			if(s != null){
				s.draw(g);
			}
		}
		
		//Display a status message 
		String sheepnum = "Sheep Remaining:" + Integer.toString(checkSheep);
		g.drawString(sheepnum, w+10, 10);
		String robbernum = "Robber Remaining:" + Integer.toString(checkRobber);
		g.drawString(robbernum, w+10, 50);
	}
	@Override
	public void keyPressed(KeyEvent k) {
		char kit = k.getKeyChar();
		System.out.print(kit);
		
		int linh = k.getKeyCode();
		
		int aPosX = a.getPos().x;
		int aPosY = a.getPos().y;
		Point nextPos = new Point(aPosX, aPosY);
		
		switch(linh){
		case KeyEvent.VK_UP:
			nextPos = new Point(nextPos.x, nextPos.y-1);
			break;
			
		case KeyEvent.VK_DOWN:
			nextPos = new Point(nextPos.x, nextPos.y+1);
			break;
			
		case KeyEvent.VK_LEFT:
			nextPos = new Point(nextPos.x-1, nextPos.y);
			break;
			
		case KeyEvent.VK_RIGHT:
			nextPos = new Point(nextPos.x+1, nextPos.y);
			break;
			
		case KeyEvent.VK_W:
			shoot(KeyEvent.VK_W);
			break;
			
		case KeyEvent.VK_S:
			shoot(KeyEvent.VK_S);
			break;
			
		case KeyEvent.VK_A:
			shoot(KeyEvent.VK_A);
			break;
		
		case KeyEvent.VK_D:
			shoot(KeyEvent.VK_D);
			break;
				
		}
		
		if (nextPos.x <= col && nextPos.y <=row && nextPos.x >= 1 && nextPos.y >= 1 && !hitATree(nextPos)) {
			a.setLocation(nextPos);
			repaint();
		}
		
		//make sheep invisible
		for(int i=0; i < flock.size(); i++){
			if (flock.get(i) == null){
				continue;
			}
			if(a.equal(flock.get(i))) {
				flock.set(i,null);
				checkSheep--;
				System.out.println(checkSheep);
				repaint();
				break;
			}
		}
		if(checkSheep == 0 ) {
			playSound();
			JOptionPane.showMessageDialog(null,"Congratulation for rescuing all the sheep!");
			System.out.println("sheep rescued");
			reset();
		}
		
		
		//touch any of the waters
		for(int i=0; i < water.size(); i++){
			if(a.equal(water.get(i))) {
				JOptionPane.showMessageDialog(null,"Ammon died, Game Over! Water");
				System.out.println("Ammon died");
				reset();
				break;
			}
		}
		
		//next to any of the robbers
		for(int i=0; i < badguys.size(); i++){
			if(badguys.get(i) == null){
				continue;
			}
			if(a.isNear(badguys.get(i))) {
				JOptionPane.showMessageDialog(null,"Ammon died, Game Over! Robber");
				System.out.println("Ammon died");
				reset();
				break;
			}
		}
	}
	private void playSound(){
		URL u3 = null;
		try {
			u3 = new URL("file:victory.wav");
		}catch (Exception e1){
			e1.printStackTrace();
		}
		AudioClip p = Applet.newAudioClip(u3);
		p.play();
	}
	private void reset(){
		flock.clear();
		badguys.clear();
		forest.clear();
		water.clear();
		readMap("map2.txt");
		checkSheep = flock.size();
		checkRobber = badguys.size();
		repaint();
		
	}
	private boolean hitATree(Point p) {
		for (int i=0; i < forest.size(); i++) {
			if (forest.get(i).getPos().x == p.x && forest.get(i).getPos().y == p.y){
				return true;
			}
		}
		return false;
	}
	@Override
	public void keyReleased(KeyEvent k) {}
	@Override
	public void keyTyped(KeyEvent k) {}
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setContentPane(new Game());
		window.setSize(w,h);
		window.setVisible(true);
	}

}


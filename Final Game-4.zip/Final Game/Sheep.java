import javax.swing.ImageIcon;

public class Sheep extends Sprite {
	
	public Sheep(int x, int y){
		super();
		image = new ImageIcon("sh.png");
		setLocation(x,y);
	}
	
}

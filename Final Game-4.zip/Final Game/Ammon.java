import javax.swing.ImageIcon;

public class Ammon extends Sprite {
	
	public Ammon(int x, int y){
		super();
		image = new ImageIcon("ammon.png");
		setLocation(x,y);
	}


	
}

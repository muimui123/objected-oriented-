import java.awt.Color;
import java.awt.Graphics;

public class Water extends Sprite {
	
	public Water(int x, int y){
		super();
		image = null;
		setLocation(x,y);
	}
	
	@Override
	public void draw(Graphics g){
		g.setColor(Color.BLUE);
		g.fillRect(absolutePosition.x,absolutePosition.y,Game.eachw,Game.eachh);		
	}
	
}
